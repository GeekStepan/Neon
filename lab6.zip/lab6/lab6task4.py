def lab6task4(x):
    n = 1
    matrixList = [[0 for i in range(x)] for i in range(x)]
    for i in range(x):
        print(matrixList[i])

    for i in range(x):
        for j in range(x):
            matrixList[i][j] = n
            n += 1

    for i in range(x):
        print(matrixList[i])

lab6task4(5)


'''                                                                 '''
     [0] [1] [2] [3] [4]                           |                |
[0]   1   22  23  14  13   [00][10][20][30][40]    |   [21][11][01] |
[1]   2   21  24  15  12   [41][42][43][44]        |   [02][12][22] |  
[2]   3   20  25  16  11   [34][24][14][04]        |                |
[3]   4   19  18  17  10   [03][13][23]            |                |
[4]   5   6   7   8   9    [33][32][31]            |                |    
'''                                                                 '''
